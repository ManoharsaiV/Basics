package com.printprimes;

public class PrintPrimes {
	public static void primes() {

		for (long i = 1; i < 1000; i++) {
			int count = 0;
			for (long j = 1; j <= i; j++) {

				if (i % j == 0) {
					count++;
				}

			}
			if (count == 2) {
				System.out.println(i);
			}

		}

	}

	public static void main(String[] args) {
		primes();
	}

}
