package com.toldyasilly;

public class Silly {
	
	public static void main(String[] args) {
		byte b = 10;
		b = (byte) (b*b);
		System.out.println(b);
	}

}
