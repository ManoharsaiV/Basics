package com.selectionsort;

public class SelectionSort {

	public static void selectionSort(int[] arr) {
		int min_index, i, j;
		for (i = 0; i < arr.length; i++) {
			min_index = i; // assumption that the first element is the smallest
			for (j = i + 1; j < arr.length; j++) {
				if (arr[min_index] > arr[j]) {
					min_index = j; // if the element at index j is smaller than the element at min_index then

				} // now we have to swap those two elements at min_index and j

			}
			int temp = arr[min_index];
			arr[min_index] = arr[i];
			arr[i] = temp;
		}
	}

	public static void main(String[] args) {
		int[] a = { 5, 3, 2, 1, 1 };
		selectionSort(a);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);

		}

	}

}
// 