package com.quicksort;

public class QuickSort {

	public static int sortByPivot(int[] arr, int low, int high) {
		int index;
		int n = high;
		int pivot = low;
		index = low + 1;
		for (int current = low + 1; current < n; current++) {
			if (arr[pivot] > arr[current]) {
				int temp = arr[current];
				arr[current] = arr[index];
				arr[index] = temp;
				index++;
			}

		}
		int temp = arr[pivot];
		arr[pivot] = arr[index - 1];
		arr[index - 1] = temp;

		return (index - 1);
	}

	public static void quickSort(int[] arr, int low, int high) {
		if (low < high) {
			int p = sortByPivot(arr, low, high);
			System.out.print(" ( " + low + "," + high + ")");
			for (int i = 0; i < arr.length; i++) {
				System.out.print(arr[i] + " ");
			}
			System.out.println("----" + p + " ");
			quickSort(arr, low, p);
			quickSort(arr, p + 1, high);
		}

	}

	public static void main(String[] args) {
		int arr[] = { 5, 4, 3, 2, 1 };
		quickSort(arr, 0, 5);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

}
