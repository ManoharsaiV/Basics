package com.dynamicarraycreation;

import java.util.Scanner;

public class DynamicArray {
	public static void dynamicArray() {
		dataType[] array = new dataType[size_Array];
		
		
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the data type of the array");
		String dataType = scan.nextLine();
		System.out.println("Enter the size of the array");
		int size_Array = scan.nextInt();
		dynamicArray();
		System.out.println("Enter the elements into the array");
		for(int i=0; i<size_Array-1; i++){
			array[i] = scan.nextInt();
		}
	}

}
