package com.bubblesort;

public class BubbleSort {
	
	public static void bubbleSort(int[] arr) {
		int i,j,temp;
		for(i=0; i<arr.length; i++){
			for(j=i+1; j<arr.length;j++){
				if(arr[i]>arr[j]){
					// swap
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
			
			}
		}
		
	
	
	
	public static void main(String[] args) {
		int[] a = {6,0,1,2,1};
		bubbleSort(a);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
	}

}
