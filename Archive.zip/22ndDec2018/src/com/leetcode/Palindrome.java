package com.leetcode;

import java.util.Scanner;

class Palindrome {
//	public boolean isPalindrome(int x) {
//		Integer i = new Integer(x);
//		String s = i.toString();
//		StringBuilder sb = new StringBuilder();
//		sb = sb.append(s);
//		if (sb.reverse().toString().equals(s)) {
//			System.out.println(true);
//			return true;
//		} else {
//			System.out.println(false);
//			return false;
//		}
//	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int x = scan.nextInt();
		scan.close();
		//Palindrome s = new Palindrome();
		//s.isPalindrome(x);
		palindromeNumber(x);

	}
	
//	class Solution {
//	    public boolean isPalindrome(int x) {
//	        if(x < 0) return false;
//	        String s = x + "";
//	        char[] c = s.toCharArray();
//	        int len = c.length;
//	        for(int i = 0; i < len / 2; i++) {
//	            if(c[i] != c[len - i - 1]) return false;
//	        }
//	        return true;
//	    }
//	}
	
	static boolean palindromeNumber(int input) {
        if (input < 0) {
        	System.out.println(false);
        	return false;
        }
        int originalNumber = input;
        int reverseNumber = 0;
        while (originalNumber != 0) {
            reverseNumber *= 10;
            reverseNumber += originalNumber % 10;
            originalNumber /= 10;
        }
        System.out.println(reverseNumber == input);
        return reverseNumber == input;
}
}

