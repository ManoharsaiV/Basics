package com.mergesort;

public class MergeSort {
	public static void mergeSort(int[] arr, int lFirst, int mSecond, int rEnd) {
		// arr[] is the main array where the two sub arrays get merged into
		// lFirst is the index from where the left sub array starts from
		// mSecond is the index from where the left sub array ends at
		// so obviously, mSecond + 1 is where the right sub array starts from
		// rEnd is where the second array ends at
		int lenOfLeftArray, lenOfRightArray;
		// the sizes of the two sub arrays
		lenOfLeftArray = mSecond - lFirst + 1;
		lenOfRightArray = rEnd - mSecond;
		// create the two temporary sub arrays
		int[] leftSubArray = new int[lenOfLeftArray];
		int[] rightSubArray = new int[lenOfRightArray];
		// copy the data into the above created sub arrays
		for (int i = 0; i < lenOfLeftArray; i++) {
			leftSubArray[i] = arr[lFirst + i];
		}
		for (int j = 0; j < lenOfLeftArray; j++) {
			rightSubArray[j] = arr[mSecond + 1 + j];
		}
		
		// careful, now we are merging the two sub arrays after 
		// checking for some conditions
		//only if those conditions are passed, we get to merge them into  
		//  another array and this happens till all the elements are sorted
		
		// we know, for both leftSubArray/rightSubArray the initial index is 0
		// i.e, i = 0, j = 0
		int i = 0, j=0;
		// the initial index of the merged array of these two sub arrays is 1
		int k = 1;
		
		while(i < lenOfLeftArray && j<lenOfRightArray) {
			if (leftSubArray[i] <= rightSubArray[j]) 
            { 
                arr[k] = leftSubArray[i]; 
                i++; 
            } 
            else
            { 
                arr[k] = rightSubArray[j]; 
                j++; 
            } 
            k++; 
        } 
  
        /* Copy remaining elements of leftSubArray[] if any */
        while (i < lenOfLeftArray) 
        { 
            arr[k] = leftSubArray[i]; 
            i++; 
            k++; 
        } 
  
        /* Copy remaining elements of R[] if any */
        while (j < lenOfRightArray) 
        { 
            arr[k] = rightSubArray[j]; 
            j++; 
            k++; 
        } 
    } 
  
		
	}


