package com.java8timestuff;

import java.time.LocalTime;

public class Java8TimeStuff {

	public static void main(String[] args) {
		LocalTime localTime = LocalTime.of(01, 05);
		System.out.println(localTime);
		LocalTime localTimeSecondConstructor = LocalTime.of(1, 05, 48);
		System.out.println(localTimeSecondConstructor);
		LocalTime lTime = LocalTime.parse("01:05:48");
		System.out.println(lTime);
	}

}
