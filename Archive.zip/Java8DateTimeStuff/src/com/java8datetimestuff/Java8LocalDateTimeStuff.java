package com.java8datetimestuff;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Java8LocalDateTimeStuff {

	public static void main(String[] args) {
		LocalDate localDate = LocalDate.of(2019, 2, 17);
		LocalTime localTime = LocalTime.of(12, 53, 26);
		LocalDateTime dt = LocalDateTime.of(localDate, localTime);
		System.out.println(dt);
		LocalDate date = dt.toLocalDate();
		System.out.println(date);
		LocalTime time = dt.toLocalTime();
		System.out.println(time);
		LocalDateTime t = localDate.atTime(localTime);
		System.out.println(t);
		LocalDateTime d = localTime.atDate(localDate);
		System.out.println(d);
		LocalDateTime ldt = LocalDateTime.now();
		System.out.println(ldt);
		

	}

}
