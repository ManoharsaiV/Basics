package com.java8datestuff;

import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

public class Java8DateStuff {

	public static void main(String[] args) {
		LocalDate localDate = LocalDate.of(2019, 2, 16);
		LocalDate local = LocalDate.now();
		System.out.println(local);
		int year = localDate.getYear();
		System.out.println(year);
		Month month = localDate.getMonth();
		System.out.println(month);
		int day = localDate.getDayOfYear();
		System.out.println(day);
		System.out.println(localDate.get(ChronoField.YEAR));
		System.out.println(localDate.get(ChronoField.DAY_OF_WEEK));
		System.out.println(localDate.get(ChronoField.DAY_OF_MONTH));
		LocalDate lDate = LocalDate.parse("2019-02-17");
		System.out.println(lDate);
		LocalDate date1 = LocalDate.of(2014, 03, 18);
		LocalDate date2 = date1.plus(1, ChronoUnit.WEEKS);
		System.out.println(date2);
		LocalDate date3 = date1.minus(02, ChronoUnit.MONTHS);
		System.out.println(date3);
		LocalDate date4 = date1.plusMonths(4);
		System.out.println(date4);
		date1 = date1.with(ChronoField.YEAR, 2019).minus(01,ChronoUnit.MONTHS).minus(1, ChronoUnit.DAYS);
		System.out.println(date1);
	}

}
