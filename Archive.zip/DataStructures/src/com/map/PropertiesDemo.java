package com.map;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class PropertiesDemo {

	public static void main(String[] args) throws Exception {
		File f = new File("abc.properties");
		f.createNewFile();		
		Properties p = new Properties();
		FileInputStream fis = new FileInputStream("abc.properties");
		p.load(fis);
		System.out.println(p); // {propertyname = propertyvalue}
		String s = p.getProperty("venky");
		System.out.println(s);// 9999
		p.setProperty("nag", "888888");
		FileOutputStream fos = new FileOutputStream("abc.properties");
		p.store(fos, "updated by manohar");

	}

}
