package com.map;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		// same as HashMap except that insertion order is maintained in LinkedHashMap
		

	}

}
