package com.map;

import java.util.Map;
import java.util.WeakHashMap;

public class WeakHashMapDemo {
	static WeakHashMapDemo w = new WeakHashMapDemo();

	public static void main(String[] args) throws InterruptedException {
		Map<Object, String> weakmap = new WeakHashMap<Object, String>();
		Test t = w.new Test();
		weakmap.put(t, "durga");
		System.out.println(weakmap);
		t = null;
		System.gc();
		Thread.sleep(5000);
		System.out.println(weakmap);
		

	}
	
	class Test{

		@Override
		public String toString() {
			return "Test";
		}
		public void finalize() {
			System.out.println("Finalize method invoked");
		}
		
	}

}
