package com.map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		Map<String, Integer> hashmap = new HashMap<String, Integer>();
		hashmap.put("Chiranjeevi", 1000);
		hashmap.put("Nagarjuna", 2000);
		hashmap.put("Balayya", 3000);
		hashmap.put("Venky", 4000);
		System.out.println(hashmap);
		System.out.println(hashmap.put("Chiranjeevi", 100));// returns the value replaced by 100 i.e; 1000
		Set<String> s = hashmap.keySet(); // returns all the keys of hashmap
		System.out.println(s);
		Collection<Integer> c = hashmap.values(); // returns all the values of hashmap
		System.out.println(c);
		// entry interface specific methods are as follows
		// entry interface is a child interface of map interface and entry lies with in
		// map
		// hence with out map object - there is no way an entry interface can exist
		Set<Entry<String, Integer>> s1 = hashmap.entrySet();
		System.out.println(s1);
		Iterator<Entry<String, Integer>> itr = s1.iterator();
		while (itr.hasNext()) {
			Map.Entry<String, Integer> m1 = (Map.Entry<String, Integer>) itr.next();
			System.out.println(m1.getKey() + "---" + m1.getValue());
			if (m1.getKey().equals("Nagarjuna")) {
				m1.setValue(10000);
			}
		}
		System.out.println(hashmap);

		

	}

}
