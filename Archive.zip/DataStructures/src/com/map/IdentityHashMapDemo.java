package com.map;

//import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

public class IdentityHashMapDemo {

	public static void main(String[] args) {
		Map<Integer, String> linkedHashMap = new IdentityHashMap<Integer, String>();
//		Map<Integer, String> linkedHashMap = new HashMap<Integer, String>();
		Integer I1 = new Integer(10);
		Integer I2 = new Integer(10);
		linkedHashMap.put(I1, "Pawan");
		linkedHashMap.put(I2, "Kalyan");
		System.out.println(linkedHashMap);
		// had it been a normal HashMap the output would be
		//{10=Kalyan} 'cause internally HashMap uses I1.equals(I2) i.e, only content is checked
		// where IdentityHashMap uses I1 == I2 i.e, references are checked.
		

	}

}
