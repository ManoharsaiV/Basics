package com.treeset;


import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

 class Solution {
	

	public static void main(String[] args) {
		SortedSet<String> ts = new TreeSet<String>(new MyComparator());
		
		ts.add("Amma");
		ts.add("Nanna");
		ts.add("Santosh");
		ts.add("adon");
		ts.add("xenon");
		//ts.add(new StringBuilder("hello"));
		System.out.println(ts);

	}

}
 
 class MyComparator implements Comparator<String>{

	

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		String s1 = o1.toString();
		String s2 = o2.toString();
		
		return -s1.compareTo(s2);
	}
	 
 }



