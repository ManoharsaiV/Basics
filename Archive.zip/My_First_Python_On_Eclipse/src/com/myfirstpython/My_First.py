'''
Created on 19-Feb-2019

@author: manoharveerubhotla
'''

print("Manohar");
print(int(12.55));
