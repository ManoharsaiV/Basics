package com.probabilitycheck;

import java.util.Scanner;

//
//First, you need to help Chef pick a door (let's denote it by X
//). Then, the host opens a different door (let's denote it by Y
//) such that there is a goat behind this door, and asks Chef to pick an arbitrary door again (let's denote it by Z
//). You need to help Chef pick door Z
// too. You should do it in such a way that the probability of a car being behind door Z
// is maximised. If there are multiple optimal possible ways to pick doors for Chef, you may choose any one.
//
//Interaction
//First, you should print a line containing a single integer X
// (1≤X≤3
//).
//Then, you should read a line containing a single integer Y
//.
//Finally, you should print a line containing a single integer Z
// (1≤Z≤3
//).
//Don't forget to flush the output after printing each line!

public class ProbabilityCheck {
	public static void openDoors() {
		int x = 1;// goat
		System.out.println(x);
		Scanner scan = new Scanner(System.in);
		int y = scan.nextInt(); // goat
		scan.close(); 
		if (y == 2) {
			System.out.println(3);
		} else if (y == 3) {
			System.out.println(2);
		}

	}

	public static void main(String[] args) {
		openDoors();

	}

}
