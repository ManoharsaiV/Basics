package com.basicstuff;

public class Instructor {
	public int id;
	public String name;
	public String title;
	public String department;
	public Books[] books;
	public Instructor(int id, String name, String title, String department, Books[] books) {
		this.id = id;
		this.name = name;
		this.title = title;
		this.department = department;
		this.books = books;
	}
	

}
