package com.donewheniamdrunk;

public class Drunk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Double d = Double.valueOf("120D");
		System.out.println(d);

	}

}
