package com.fileio;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIO {
//	public static void file_IO_Basics() {
//		File f = new File("/Users/manoharveerubhotla/Downloads");
//		String[] s = f.list();
//		int count = 0;
//		for (String s1 : s) {
//			File f1 = new File(f, s1);
//			
//			if (f1.isDirectory()) {
//				count++;
//				System.out.println(s1);
//			}
//
//		}
//		System.out.println(count);
//		
//	}



	public static void main(String[] args) throws IOException {
		File f = new File("sample_folder");
		f.mkdirs();
		File f1 = new File(f, "sample.txt");
		f1.createNewFile();
		FileWriter fw = new FileWriter(f1, true);
		String str = "Nobody cares for you. They mind their own lives. Trust me!\n";
		fw.write(str);
		System.out.println();
		fw.write(str);
		fw.flush();
		fw.close();
		
		
		
		
		
		FileReader fr = new FileReader(f1);
		char[] c = new char[(int)f1.length()];
		fr.read(c);
		for(char c1: c) {
			System.out.print(c1);
		}
		System.out.println("----------------------------------");
		System.out.println("----------------------------------");
		System.out.println("----------------------------------");
		int i = fr.read();
		while(i!=-1) {
		 System.out.print((char)i);
		 i = fr.read();
		}
		System.out.println("----------------------------------");
		System.out.println("----------------------------------");
		System.out.println("----------------------------------");
		
		fr.close();
		

	}

}
