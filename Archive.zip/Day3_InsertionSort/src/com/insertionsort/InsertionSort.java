package com.insertionsort;

public class InsertionSort {
	public static void insertionSort(char[] str) {
		char temp;

		// loop 1 for traversing through the array
		for (int i = 1; i < str.length; i++) {
			temp = str[i];
			// loop 2 for comparing the elements in the array

			for (int j2 = i; j2 > 0 && temp < str[j2 - 1]; j2--) {

				str[j2] = str[j2 - 1];
				str[j2 - 1] = temp;

			}

		}

	}

	public static void main(String[] args) {
		char[] a = { 'a', 'n', 'a', 'g', 'r', 'a', 'm' };
		insertionSort(a);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}

	}

}
