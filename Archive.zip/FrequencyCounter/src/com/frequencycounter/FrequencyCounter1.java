package com.frequencycounter;

import java.util.Scanner;

public class FrequencyCounter1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scan = new Scanner(System.in);
	        int num = scan.nextInt();
	        scan.close();
	        int[] count_Array = new int[10];
	       while(num != 0){
	           count_Array[num%10]++;
	           num /= 10;
	       }
	       for(int i=0; i<count_Array.length; i++){
	           if(count_Array[i] != 0){
	       System.out.println(i + " - "+ count_Array[i]);
	           }
	       }
	    }

	}



