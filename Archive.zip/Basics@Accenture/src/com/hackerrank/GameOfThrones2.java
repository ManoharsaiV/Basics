package com.hackerrank;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class GameOfThrones2 {

	// Complete the gameOfThrones function below.
	static String gameOfThrones(String str) {
		String result1 = "";
		Map<Character, Integer> gMap = new HashMap<Character, Integer>();
		char[] characterArray = str.toCharArray();
		for (char ch : characterArray) {
			if (gMap.containsKey(ch)) {
				Integer frequency = gMap.get(ch);
				gMap.put(ch, (frequency == null) ? 1 : frequency + 1);
			} else {
				gMap.put(ch, 1);
			}
		}
		// System.out.println((gMap.values()));
		Object[] charArray;
		int count = 0;
		charArray = gMap.values().toArray();
		if (str.length() % 2 != 0) {
			for (int i = 0; i < charArray.length; i++) {
				if (Integer.parseInt(charArray[i].toString()) % 2 != 0) {
					count++;
				}
				
			}
			if (count == 1) {
				//System.out.println("YES");
				result1 = "YES";
			}else {
				System.out.println("NO");
				result1 = "NO";
			}
		}if(str.length() % 2 == 0) {
			for (int i = 0; i < charArray.length; i++) {
				if (Integer.parseInt(charArray[i].toString()) % 2 != 0) {
					count++;
				}
				
			}
			if (count == 0) {
				System.out.println("YES");
				result1 = "YES";
			}else {
				System.out.println("NO");
				result1 = "NO";
			}
			
		}

		return result1;

	}

	static boolean palindrome(String str) {
		boolean result = false;
		if (str.length() != 0) {
			StringBuilder sb = new StringBuilder();
			String newString = sb.append(str).reverse().toString();
			if (str.contentEquals(newString))
				result = true;
			else
				result = false;
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		String result = gameOfThrones(str);
		scan.close();
		System.out.println(result);

	}

}
