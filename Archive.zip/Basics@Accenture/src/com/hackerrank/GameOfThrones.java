package com.hackerrank;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class GameOfThrones {

	static String gameOfThrones(String s) {
        String result = "NO";
         Set<Character> set = new HashSet<Character>();
    for(Character ch : s.toCharArray()){
        if(set.contains(ch)){
            set.remove(ch);
        }else{
            set.add(ch);
        }
    }
    System.out.println(set);
    if(set.size()<=1){
        result = "YES";
        return result;
    }
    return result;

    }


	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		String result = gameOfThrones(str);
		scan.close();
		System.out.println(result);

	}

}