package com.hackerrank;

import java.util.Scanner;

class Series{
    public static void main(String []argh){
        Scanner in = new Scanner(System.in);
        int t=in.nextInt();
        for(int i=0;i<t;i++){
        int a = in.nextInt();
        int b = in.nextInt();
        int n = in.nextInt();
        doJob(a,b,n);
        }
        in.close();
        
        
    }
    public static void doJob(int a, int b, int n){
    int result=0;
    result = a+result;
    for (int i = 0 ;i<n;i++){
    result =result + (int)Math.pow(2, i)*b;
    System.out.print(result + " "); 
    }
    System.out.println();
}
}


