package com.hackerrank;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class StringModificationOperations {
	
	public static int checkString(String str) {
		Map<Character, Integer> hashMap = new HashMap<>();
		char[] charArray = str.toCharArray();
		for(char ch : charArray) {
			if(hashMap.containsKey(ch)) {
				hashMap.put(ch, hashMap.get(ch) + 1);
			}
			else {
				hashMap.put(ch, 1);
			}
		}
		Collection<Integer> cValues = hashMap.values();
		System.out.println(cValues);
		
				
		return 0;
	}

	public static void main(String[] args) {
		//Scanner scan = new Scanner(System.in);
		checkString("aaabc");
	}

}
