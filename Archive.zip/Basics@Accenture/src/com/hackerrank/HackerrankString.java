package com.hackerrank;

import java.util.Scanner;
import java.util.Stack;

public class HackerrankString {
	
	static String hackerrankInString(String s) {
        // Complete this function
        Stack<Character> stack= new Stack<Character>();
        stack.push('k');
        stack.push('n');
        stack.push('a');
        stack.push('r');
        stack.push('r');
        stack.push('e');
        stack.push('k');
        stack.push('c');
        stack.push('a');
        stack.push('h');
        
        String result="NO";
        for(Character c:s.toCharArray()){
            if(c==stack.peek()) {
                stack.pop();
            }
            if(stack.isEmpty()){
                result="YES";
                break;
            } 
        }
        return result;
    }

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		String result = hackerrankInString(str);
		scan.close();
		System.out.println(result);

	}

}
