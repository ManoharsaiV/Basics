package com.hackerrank;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

class DayOfWeek {

	

	public String findDay(int month, int day, int year) {
		LocalDate da = LocalDate.now();
		da = LocalDate.of(year, month, day);
		String dayString = "";
		dayString = da.getDayOfWeek().toString();
		return dayString;
	}

	public static void main(String[] args) throws IOException {
		DayOfWeek da = new DayOfWeek();
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the month day year with spaces");
		
		String[] str = scan.nextLine().split(" ");
		scan.close();
		int month = Integer.parseInt(str[0]);
		int day = Integer.parseInt(str[1]);
		int year = Integer.parseInt(str[2]);
		String result = da.findDay(month, day, year);
		System.out.println(result);

	}

}
