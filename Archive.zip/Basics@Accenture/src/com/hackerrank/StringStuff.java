package com.hackerrank;

import java.util.Scanner;

public class StringStuff {
	
	public static String reversedModifiedString(String str) {
		String result;
		StringBuilder sb = new StringBuilder();
		result = sb.append(str).reverse().toString().toLowerCase();
		char[] arrChar = result.toCharArray();
		arrChar[0] = (char) ((char) arrChar[0] - 32);
		result = String.valueOf(arrChar);
		sb = null;
		return result;
		
	}
	
	

	
	
	

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String[] str = scan.nextLine().split(" ");
		for(String s : str) {
		String result = reversedModifiedString(s);
		System.out.print(result );
		System.out.print(" ");


		}
		scan.close();
		
	}

}
