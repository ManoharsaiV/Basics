package com.cdacmain;

public class Test {
	public static void throwIt() throws Exception {
		throw new Exception();
	}

	public static void main(String[] args) {
		try {
			throwIt();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Hey There");
		} finally {
			System.out.println("in Finally");
		}
	}
}