package com.askedharshitainInterview;

import java.util.Scanner;

public class StringPermutations {
	
	public static String[] stringVariations(String str) {
		
		return null;
	}
	
	

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		String[] result = stringVariations(str);
		scan.close();
		System.out.println(result);

	}

}
