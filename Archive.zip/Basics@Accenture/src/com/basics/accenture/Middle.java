package com.basics.accenture;

public class Middle extends GopiDoubt {
	
	@Override
	public void display() {
		setId(22);
		System.out.println(getId());
	}

}
