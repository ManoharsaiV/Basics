package com.basics.accenture;

class Parent{
	Parent(){
		System.out.println("parent constructor");
	}
	void parentMethod() {
		System.out.println("parent method");
	}
}

class Child extends Parent{
	Child(){
		System.out.println("child constructor");
	}
	void childMethod() {
		System.out.println("child method");
	}
}




public class TestSuper {
	public static void main(String[] args) {
		Child c = new Child();
		c.parentMethod();
		Parent p = new Child();
		p.parentMethod();
		
		
	}

}
