package com.basics.accenture;

public class GopiAsked  {

	public static void main(String[] args) {
		Middle m = new Middle();
		m.display();
	}

}
