package com.basics.accenture;

import java.util.Scanner;

public class Factorial {
	
	
	public static int factorial(int number) {
		int factorialOfNum = 1;
		if(number==0) factorialOfNum = 1;
		if(number > 0) 
	    factorialOfNum = number * factorial(number-1);
		
		return factorialOfNum;
		
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int number = scan.nextInt();
		int result = factorial(number);
		System.out.println(result);
		scan.close();

	}

}
