package com.basics.accenture;

import java.util.Scanner;

public class ReverseNum {

	public static int reverseNum(int number) {
		int reversedNum = 0;
		while (number != 0) {
			int digit = number%10;
			reversedNum = reversedNum * 10 + digit;
			number /= 10;

		}
		return reversedNum;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int number = scan.nextInt();
		int result = reverseNum(number);
		System.out.println(result);
		scan.close();
	}

}
