package com.basics.accenture;

import java.util.Scanner;

public class Palindrome {

	public static void palindrome(int number) {
		int reverseNum = 0, temp = number;
		while (number != 0) {
			int digit = number % 10;
			reverseNum = reverseNum * 10 + digit;
			number /= 10;
		}
		if (temp == reverseNum)
			System.out.println("Palindrome");
		else
			System.out.println("Not a Palindrome");

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int number = scan.nextInt();
		palindrome(number);
		scan.close();

	}

}
