package com.basics.accenture;

import java.util.Scanner;

public class LinearSearch {

	public static int linearSearch(int[] array, int number) {
	
		for (int i = 0; i < array.length; i++) {
			if (array[i] == number) {
				System.out.println("Number Found");
				return i;
			}

		}
		System.out.println("Number Not Found");
		return -1;

	}

	public static void main(String[] args) {
		int[] array = {5, 4, 3, 2, 1};
		Scanner scan = new Scanner(System.in);
		int number = scan.nextInt();
		linearSearch(array, number);
		scan.close();

	}

}
