/**
 * 
 */
/**
 * @author manoharveerubhotla
 *
 */
package com.hackerrank.timeconversion;