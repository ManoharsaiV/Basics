package com.hackerrank.timeconversion;


import java.util.Scanner;

public class Solution {
	public static String timeConversion(String s) {
		String hour = s.substring(0, 2);
		String min = s.substring(3, 5);
		String sec = s.substring(6, 8);
		char sunlight = s.charAt(s.length() - 2);
		StringBuilder time24 = new StringBuilder();

		if (sunlight == 'A' && Integer.parseInt(hour) == 12)
			time24.append("00");
		else if (sunlight == 'P' && Integer.parseInt(hour) != 12)
			time24.append(Integer.parseInt(hour) + 12);
		else
			time24.append(hour);

		time24.append(":" + min + ":" + sec);

		return time24.toString();

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String s = scan.nextLine();
		scan.close();
		String result = timeConversion(s);
		System.out.println(result);

	}
}
