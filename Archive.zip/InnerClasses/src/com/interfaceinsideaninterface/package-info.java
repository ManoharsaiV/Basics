/**
 * 
 */
/**
 * @author manoharveerubhotla
 *
 */
package com.interfaceinsideaninterface;