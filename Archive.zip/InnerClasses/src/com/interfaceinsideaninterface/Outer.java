package com.interfaceinsideaninterface;

public interface Outer {
	 

}
