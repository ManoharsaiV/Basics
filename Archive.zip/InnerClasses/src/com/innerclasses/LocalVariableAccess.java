package com.innerclasses;

public class LocalVariableAccess {
// Note that local variable(x) must be final till JDK 7  
// hence this code will work only in JDK 8 
	
	public void methodOuter() {
		 int x = 10;
		class Inner{
			public void methodInner() {
				//x = 11;
				System.out.println(x);
			}
		}
		Inner i = new Inner();
		i.methodInner();
	}

	public static void main(String[] args) {
		LocalVariableAccess lva = new LocalVariableAccess();
		lva.methodOuter();

	}

}
