package com.hackerrank.gradingstudents;

import java.util.Scanner;

public class GradingStudents {
	// grade can be any where between 0 to 100 and any grade below 40 is a
	// failing grade
	// difference between the grade and next multiple of 5 is less than 3 ,
	// round the
	// grade up to next multiple of 5
	// if grade < 38, no rounding occurs as the result will still be a failing
	// grade

	// public static int[] grading(int[] grades) {
	// for (int i = 0; i < grades.length; i++) {
	// if (grades[i] < 38)
	// grades[i] = grades[i];
	// else if (grades[i] >= 38) {
	// if (grades[i] % 5 == 0)
	// grades[i] = grades[i];
	// else {
	// if ((grades[i] + 1) % 5 == 0)
	// grades[i] += 1;
	// else if ((grades[i] + 2) % 5 == 0)
	// grades[i] += 2;
	// }
	//
	// }
	// }
	// }

	public static int[] grading(int[] grades) {
		for (int i = 0; i < grades.length; i++) {
			int remainder = grades[i] % 5;
			if (grades[i] >= 38 && remainder > 2)
				grades[i] = grades[i] + (5 - remainder);
			else {
				grades[i] = grades[i];
			}

		}
		System.out.println("rounded up grades");
		for (int i = 0; i < grades.length; i++) {
			System.out.println(grades[i]);
		}

		return grades;
	}

	public static void main(String[] args) {
		System.out.println("enter the number of students: ");
		Scanner sc = new Scanner(System.in);
		int inumber = sc.nextInt();
		System.out.println("enter their individual marks");
		int[] studentsMarks = new int[inumber];
		for (int i = 0; i < studentsMarks.length; i++) {
			studentsMarks[i] = sc.nextInt();
		}
		grading(studentsMarks);
		sc.close();

	}

}
