package com.hackerrank.videoconference;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

public class VideoConference {
	public static List<String> shortNames(List<String> names) {
		// List<String> shortName = new ArrayList<String>();
		// Hashtable<String,String> hashTable = new Hashtable<String,String>();
		// hashTable.

		// return shortName;
		Hashtable<String, String> hashTable = new Hashtable<String, String>();
		List<String> result = new ArrayList<String>();
		for (int i = 0; i < names.size(); i++) {
			String s = names.get(i);
			System.out.println(i + ": "+ s);
			String value = hashTable.get(s);
			if (value == null) {
				hashTable.put(s, s);
				result.add(s);
			} else {
				String j = "1";
				while (true) {
					String newValue = value.concat(j);
					if (hashTable.get(newValue) == null) {
						hashTable.put(newValue, s);
						result.add(newValue);
						
						break;
					} else {
						j += 1;
					}
				}

			}

		}

		return result;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number of users that are going to participate in the video conference\n");
		int n = sc.nextInt();
		System.out.println("enter the names of the users\n");
		List<String> names = new ArrayList<String>();
		for (int i = 0; i <= n; i++) {
			names.add(sc.nextLine());
		}
		sc.close();
		for(int i=0; i<names.size(); i++){
			System.out.println(names.get(i));
		}

		List<String> result;
		result = shortNames(names);
		
		
		
		for(int i=0; i<result.size(); i++){
			System.out.println(result.get(i));
		}

	}

}
