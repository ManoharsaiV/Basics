/**
 * 
 */
/**
 * @author manoharveerubhotla
 *
 */
package com.hackerrank.kangaroojumps;