package com.singlylinkedlist;

public class SinglyLinkedList {
	Node newNode = new Node();
	
	
	

}

class Node{
	int data;
	Node next;
}
