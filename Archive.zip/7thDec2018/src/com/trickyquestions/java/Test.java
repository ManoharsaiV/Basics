package com.trickyquestions.java;


public class Test {
	public static void main(String[] args) {
		foo(null);
	}
	public static void foo(Object o) {
		System.out.println("Object impl");
	}
	public static void foo(String s) {
		System.out.println("String impl");
	}
//	public static void foo(StringBuilder s) {
//		System.out.println("StringBuilder impl");
//	}
}

//I know this before. In method overloading, if a method is invoked as shown above, at run time - the method with String as parameter is invoked at run time 'cause - method which is more specific should be invoked.