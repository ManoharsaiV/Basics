package com.trickyquestions.java;

public class Test3 {

	public static void main(String[] args) {
		 System.out.println(Math.min(Double.MIN_VALUE, 0.0d)); 
		 
		

	}

}


