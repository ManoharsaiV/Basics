package com.collections;

import java.util.ArrayList;
import java.util.Collection;

public class Solutions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Collection<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		Collection<Integer> list1 = new ArrayList<Integer>();
		list1.add(1);
		list1.add(3);
//		ArrayList<Integer> lnList;
		list.retainAll(list1);
		System.out.println(list);
		
		

	}

}
