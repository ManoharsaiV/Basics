package com.onlyhackerrank;

import java.util.Scanner;

public class BinaryString {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String s = scan.nextLine();
		

	}
	
	public static String magicString(String str) {
		
		return str;
		
	}

}
