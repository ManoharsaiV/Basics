package com.onlyhackerrank;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BirthdayChocolate {

	static int birthday(List<Integer> s, int d, int m) {
		int count = 0;
		
		for (int i = 0; i < s.size(); i++) {
			int r = s.get(i);
			
			for (int j = 1; j < s.size(); j++) {
				int q = s.get(j);
				if (r + q == d) {
					count++;
				}
			}

		}

		return 0;

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number of square in the chocolate bar");
		int num = scan.nextInt();
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < num; i++) {
			list.add(scan.nextInt());
		}
		System.out.println("enter birthdate and month");
		int birthDate = scan.nextInt();
		int birthMonth = scan.nextInt();
		scan.close();
		birthday(list, birthDate, birthMonth);

	}

}
