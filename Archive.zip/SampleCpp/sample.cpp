#include <iostream>
using namespace std;


int main() {
	int a=5;
	cout << (a<<2) << endl;
	cout<<"First"<<(a>>2)<<"Second";
//	int a =10;
//	int const &b=a;
//	a=11;

}
