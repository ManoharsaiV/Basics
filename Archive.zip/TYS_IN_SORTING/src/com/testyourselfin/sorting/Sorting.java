package com.testyourselfin.sorting;



public class Sorting implements Sort{

	@Override
	public void insertionSort(int[] arr) {
		int temp, i, j;
		for(i=1; i<arr.length; i++){
			temp = arr[i];
			for(j=i; j>0; j--){
				if(temp < arr[j-1]){
					arr[j] = arr[j-1]; // 
					arr[j-1] = temp;
					
				}
			}
		}
		
	}
	
	@Override
	public void selectionSort(int[] arr) {
		int min_index, i, j;
		for(i=0; i<arr.length; i++){
			min_index = i;
			for(j = i+1; j<arr.length; j++){
				if(arr[min_index] > arr[j]){
					min_index = j;
					// so swap
					int temp = arr[min_index];
					arr[min_index] = arr[i];
					arr[i] = temp;
					
				}
			}
		}
		
		
	}
	
	public static void main(String[] args) {
		int[] a = { 16, 12, 52, 64, 93, 21 };
		Sorting s = new Sorting();
		//s.insertionSort(a);
		s.shellSort(a);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);

		}

	
	

}

	@Override
	public void shellSort(int[] arr) {
		// TODO Auto-generated method stub
		//int gap = arr.length/2;
		int h = 1;
		while(h<arr.length/3){
			h=h*3+1;
		}
		//while(gap!=0){
		while(h!=0){
			for(int i = 0; i<arr.length;i++){
				int curr_index = i;
				//int j = i + gap;
				int j = i + h;
				if(j>= arr.length){
					break;
				}
				//for(j=i+gap;j<arr.length;j++){
				for (j = h + i; j < arr.length; j++) {
					if(arr[j] < arr[i]){
						arr[i] = arr[i] ^ arr[j];
						arr[j] = arr[i] ^ arr[j];
						arr[i] = arr[i] ^ arr[j];
					}
					curr_index = j;
				}
			}
			//gap = gap/2;
			h = (h-1)/3;
		
		}
		
	}
}
