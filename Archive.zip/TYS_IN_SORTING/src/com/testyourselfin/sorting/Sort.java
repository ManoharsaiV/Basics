package com.testyourselfin.sorting;

public interface Sort {
	public void insertionSort(int[] arr);

	public void selectionSort(int[] arr);

	public void shellSort(int[] arr);

}
