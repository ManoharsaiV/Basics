package com.towersofhanoi;

public class TowersOfHanoi {
	public static void towersOfHanoi(char source_rod, char destination_rod, char helper_rod, int disks) {
		if (disks == 1) {
			System.out.println("move disk 1 from source rod " + source_rod + " to destination rod " + destination_rod);
			return;
		}
		towersOfHanoi(source_rod, destination_rod, helper_rod, disks - 1);
		System.out.println("moves disk  " + disks + " from source rod" + " to destination_rod " + destination_rod);
		towersOfHanoi(helper_rod, source_rod, destination_rod, disks - 1);
	}
	
	public static void main(String[] args) {
		towersOfHanoi('A','B','C',4);
		
		
	}

}
