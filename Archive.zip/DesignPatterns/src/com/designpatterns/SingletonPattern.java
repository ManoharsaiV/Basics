package com.designpatterns;

public class SingletonPattern {

}
