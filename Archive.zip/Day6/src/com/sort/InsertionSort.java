package com.sort;

public class InsertionSort {

	public static void insertionSort(int[] arr) {
		for (int i = 1; i < arr.length; i++) {
			int temp = arr[i];
			for (int j = i; j > 0; j--) {
				if (temp > arr[j - 1]) {
					arr[j] = arr[j - 1];
					arr[j - 1] = temp;

				}

			}

		}
		
		
		}

	

	public static void main(String[] args) {
		int[] arr = { 55, 32, 55, 89, 44, 66 };
		insertionSort(arr);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
