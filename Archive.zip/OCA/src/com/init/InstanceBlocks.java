package com.init;

import java.util.Arrays;

public class InstanceBlocks {
	
	{System.out.println("initialization block 1");}
	
	static {
		System.out.println("static block 1");
	}
	
	static {
		System.out.println("static block 2");
	}
	
	{System.out.println("initialization block 2");}
	
	
	

	public static void main(String[] args) {
		System.out.println("hi");
		//InstanceBlocks ib = new InstanceBlocks();
		//InstanceBlocks ib1 = new InstanceBlocks();
		int[] a = {1,2,3,4};
		int[] b = {1,2,3,4};
		System.out.println(Arrays.equals(a, b));
		//Arrays.d
		

	}

}
