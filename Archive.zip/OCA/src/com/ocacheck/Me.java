package com.ocacheck;
import com.oca.Super;

public class Me extends Super {
	public static void main(String[] args) {
		//Super s = new Me();
		//s.name; not visible 'cause of default access modifier
	}

}
