package com.oca;

final public class Abstract2 extends Abstract1 {
	public Abstract2() {
		
	}
}
