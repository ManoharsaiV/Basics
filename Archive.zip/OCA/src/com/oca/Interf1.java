package com.oca;

public interface Interf1 {
	 default void method() {
		System.out.println("interf1");
	}
	 int n = 15;
	 String s = "s";

}
