package com.oca;

public interface Checkable {
	void meth();

}
