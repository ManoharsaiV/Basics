package com.oca;
import static java.lang.System.out;
class Mutant {
	public static void method_1(int a, int b, int c, int... d) {

	}

	static int i = 0;

	public static void main(String[] args) {
		//int[] args = {1,2,3};
		 //int j = 0;
		StringBuilder sb = new StringBuilder("abc");
		String s = "abc";
		sb.reverse().append("d");
		s.toUpperCase().concat("d");
		out.println(sb + " " + " " + s);
		//int x = 9;
		try {
			int[] aa = new int[5];
			System.out.println(aa[11]);
			//Double d = new Double("120D");
			//Integer i = new Integer("888.1");
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("oops " + e);
		}
		//System.out.println(x);
		for (int i = 5; i < 10; i++) 
				i++;
		System.out.println(i--);
		
//		do{
//			int y = j++;
//			System.out.println(y);
//			
//		}while(y<5);

	}

}
