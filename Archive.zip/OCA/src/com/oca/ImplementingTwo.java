package com.oca;

public class ImplementingTwo implements Interf1 {
	static int x = 1;
	static StringBuilder sb = new StringBuilder();
	public final static void main(String[] args) {
		Double d1 = 10.0/0.0;
		System.out.println(d1.isInfinite());
		System.out.println(Interf1.n);
		int x, y = 100;
		int[] arr = new int[2];
		arr[1] = 22;
		arr[2] = 33;
		System.out.println(arr[2]);
	}

}
