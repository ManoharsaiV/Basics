package com.oca;

public interface Interf2 {
	default void method() {
		System.out.println("interf2");
	}
}
