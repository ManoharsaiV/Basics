package com.oca;

public class Super {
	
	String name;

}
