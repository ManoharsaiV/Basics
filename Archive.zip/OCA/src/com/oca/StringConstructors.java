package com.oca;

public class StringConstructors {

	public static void main(String[] args) {
		char[] c = {'a','b','c'};
		String cd = "abcdef".substring(4);
		String s = new String(c);
		s += cd;
		System.out.println(s);
//		int[] a1 = {2,1,3};
//		int[] a2 = {2,1,3};
//		System.out.println(Arrays.deepEquals(a1, a2));

	}

}
