package com.oca;

public abstract class Abstract1 {

}
