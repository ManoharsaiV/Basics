package com.oca;

class First implements Checkable{

	@Override
	public void meth() {
		System.out.println("first");
		
	}
	
}





public class Check extends First implements Checkable {
	public void meth() {
		System.out.println("checking");
	}

	public static void main(String[] args) {
		First f = new First();
		Check c = (Check) f;
		c.meth();
		
	}

}
