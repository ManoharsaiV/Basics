package com.oca;
import com.ocacheck.Me;

public class Sub extends Me  {

	public static void main(String[] args) {
		//Me m = new Sub();
		//m.name; cannot access it because it's super class Me cannot access the name field. 
	}

}
