package com.arrays;

public class TwoDArrays {
	static byte b = (byte) 200;
	
	

	public static void main(String[] args) {
		int[][] a = { { 1, 3, 5 }, { 7, 8 } };
		out: for (int[] a1 : a) {
			for (int a2 : a1) {
				if (a2 == 7)
					continue;
				System.out.println(a2 + "");
				if (a2 == 3)
					break out;
			}
		}
		System.out.println(b);
	}

}
