package com.exceptions;

import java.io.IOException;

public class IOExceptionQuestion {
	
	 int n = Integer.parseInt("one");

	public static void main(String[] args) {
		
		int n = Integer.parseInt("one");
		try {
			throw method();
		}
		catch(IOException e) {
			System.out.println("caught");
		}


	}
	
	public static IOException method() {
//		try {
//			return new IOException();
//		}
//		catch(FileNotFoundException fe){
//			return new FileNotFoundException();
//		}
		return null;
	}

}
