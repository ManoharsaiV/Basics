package com.removeduplicates;

import java.util.Scanner;

public class WordCount {
	public static void wordCount(String str) {
		String[] strArray = str.split(" ");
		int count = strArray.length;
		System.out.println(count);

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int numberOfRows = scan.nextInt();
		String str = null;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < numberOfRows; i++) {
			str = scan.nextLine();
			sb = sb.append(str);
		}
		str = sb.toString();
		System.out.println(str);
		scan.close();
		wordCount(str);

	}

}
