package com.removeduplicates;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicates {

	public static int[] removeDuplicates(int[] arrayWithDuplicates) {
		Set<Integer> treeSet = new TreeSet<Integer>();
		for (int element : arrayWithDuplicates) {
			Integer elemenT = new Integer(element);
			treeSet.add(elemenT);
		}
		Integer[] boxedArrayWithOutDuplicates = new Integer[treeSet.size()];
		treeSet.toArray(boxedArrayWithOutDuplicates);
		int[] arrayWithOutDuplicates = new int[boxedArrayWithOutDuplicates.length];
		for (int i = 0; i < boxedArrayWithOutDuplicates.length; i++) {
			arrayWithOutDuplicates[i] = boxedArrayWithOutDuplicates[i];
		}
		return arrayWithOutDuplicates;

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		int[] arrayWithDuplicates = new int[size];
		for (int i = 0; i < size; i++) {
			arrayWithDuplicates[i] = scan.nextInt();
		}
		scan.close();
		int[] result = removeDuplicates(arrayWithDuplicates);
		for (int i = 0; i < result.length; i++) {
			System.out.println(result[i]);
		}
	}

}
