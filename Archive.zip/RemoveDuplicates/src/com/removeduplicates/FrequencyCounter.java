package com.removeduplicates;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class FrequencyCounter {
	public static void frequencyCounter(String str) {
		Map<Character, Integer> treeMap = new TreeMap<Character, Integer>();
		char[] chArray = str.toCharArray();
		for (char c : chArray) {
			if (treeMap.containsKey(c)) {
				treeMap.put(c, treeMap.get(c) + 1);
			} else treeMap.put(c, 1);
		}
		for(Map.Entry<Character, Integer> entryset : treeMap.entrySet()) {
			System.out.println(entryset.getKey() + "--" + entryset.getValue()); 
		}
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		scan.close();
		frequencyCounter(str);
		

	}

}
