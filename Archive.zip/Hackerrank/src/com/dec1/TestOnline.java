package com.dec1;

import java.util.List;

public class TestOnline {
	
	public static List<String> findSchedules(int workHours, int dayHours, String pattern) {
        String stringArr = pattern.trim();
        //int sum = 0;
        for(int i=0; i<stringArr.length(); i++){
            //sum += Integer.parseInt(stringArr[i]);
        } 
        
        return null;

    }

	public static void main(String[] args) {
		

	}

}
