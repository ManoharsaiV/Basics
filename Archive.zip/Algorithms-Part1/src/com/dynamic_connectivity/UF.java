package com.dynamic_connectivity;

import java.util.Scanner;

public class UF {
	UF(int N){
		
	}
	boolean connected(int p, int q) {
		return false;
		
	}
	void union(int p, int q) {
		
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int N = scan.nextInt();
		UF uf = new UF(N);
		while(N!=0) {
			int p = scan.nextInt();
			int q = scan.nextInt();
			if(!uf.connected(p, q)) {
				uf.union(p, q);
				System.out.println(p + "  "+ q);
			}
		}
		scan.close();
		
	}

}
