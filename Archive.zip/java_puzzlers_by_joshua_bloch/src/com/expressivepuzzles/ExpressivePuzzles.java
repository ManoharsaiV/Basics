package com.expressivepuzzles;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ExpressivePuzzles {
	List<Integer> list = new ArrayList<Integer>();
	public static boolean isOdd(int i) {
		/* don't get fooled by the usage of '%' */
		/* '%' wouldn't work with negative integers */
		/* prefer '&' over modulus when performance matters */
		/*
		 * think about the signs of the operands and of the result whenever you use the
		 * remainder operator. The behavior of this operator is obvious when its
		 * operands are nonnegative, but it isn’t so obvious when one or both operands
		 * are negative.
		 */
		return (i & 1) != 0;
	}

	public static void timeForChange() {
		/*
		 * always, use BigDecimal("String") constructor for monetary calculations not
		 * BigDecimal(double)
		 */
		/*
		 * avoid float and double where exact answers are required; for monetary
		 * calculations, use int, long, or BigDecimal.
		 */
		System.out.println(new BigDecimal("2.00").subtract(new BigDecimal("1.10")));
	}

	public static void longDivison() {
		/* all the factors that are multiplied together are int values. */
		/*
		 * It’s easy to fix the program by using a long literal in place of an int as
		 * the first factor in each product. This forces all subsequent computations in
		 * the expression to be done with long arithmetic. Although it is necessary to
		 * do this only in the expression for MICROS_PER_DAY, it is good form to do it
		 * in both products.
		 */
		final long MICROS_PER_DAY = 24L * 60 * 60 * 1000 * 1000;
		final long MILLIS_PER_DAY = 24L * 60 * 60 * 1000;
		System.out.println(MICROS_PER_DAY / MILLIS_PER_DAY);
	}

	public static void main(String[] args) {
		boolean result = isOdd(3);
		System.out.println(result);
		timeForChange();
		longDivison();
		

	}

}
