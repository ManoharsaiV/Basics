package com.customserialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class CustomSerialization {

	public static void main(String[] args) throws Exception {
		ClassToBeSerialized cts = new ClassToBeSerialized();

		// serialization
		FileOutputStream fos = new FileOutputStream("fileName3.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(cts);
		oos.close();

		// de-serialization
		FileInputStream fis = new FileInputStream("fileName3.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		ClassToBeSerialized cts2 = (ClassToBeSerialized)ois.readObject();
		System.out.println(cts2.userName + "---" + cts2.password);
		ois.close();

	}

}

class ClassToBeSerialized implements Serializable {
	String userName = "Manohar";
	transient String password = "AmmaNanna@5";

	private void writeObject(ObjectOutputStream oos) throws Exception {
		oos.defaultWriteObject();
		String epwd = "dummy" + password;
		oos.writeObject(epwd);

	}

	private void readObject(ObjectInputStream ois) throws Exception, IOException {
		ois.defaultReadObject();
		String dpwd = (String) ois.readObject();
		password = dpwd.substring(5);
	}
}
