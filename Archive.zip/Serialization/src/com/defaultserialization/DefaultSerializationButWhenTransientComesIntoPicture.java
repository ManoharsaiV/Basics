package com.defaultserialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class DefaultSerializationButWhenTransientComesIntoPicture {

	public static void main(String[] args) throws Exception {
		DefaultSerializationClassWithTransient dfsct = new DefaultSerializationClassWithTransient();
		//serialization
		FileOutputStream fos = new FileOutputStream("fileName2.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(dfsct);
		oos.close();
		
		//de-serialization
		FileInputStream fis = new FileInputStream("fileName2.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		DefaultSerializationClassWithTransient dfsct2 = (DefaultSerializationClassWithTransient) ois.readObject();
		System.out.println(dfsct2.name + "---" + dfsct2.pwd);
		ois.close();
	}

}

class DefaultSerializationClassWithTransient implements Serializable{
	String name = "Manohar";
	transient String pwd = "AmmaNanna@5";
}
