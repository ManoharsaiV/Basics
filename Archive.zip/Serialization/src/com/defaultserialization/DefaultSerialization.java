package com.defaultserialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class DefaultSerialization  {
	

	public static void main(String[] args) throws Exception {
		DefaultSerializationClass dsc1 = new DefaultSerializationClass();
		// serialization
		FileOutputStream fos = new FileOutputStream("fileName.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(dsc1);
		oos.close();
		
		//de-serialization
		FileInputStream fis = new FileInputStream("fileName.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		DefaultSerializationClass dsc2 = (DefaultSerializationClass)ois.readObject();
		ois.close();
		System.out.println(dsc2.name + "---"+ dsc2.pwd);
	}

	

}

class DefaultSerializationClass implements Serializable{
	String name = "Manohar";
	String pwd = "AmmaNanna@5";
}
